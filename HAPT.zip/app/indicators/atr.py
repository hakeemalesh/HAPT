"""
HAPT Average True Range (ATR)
-----------------------------

Calculates market volatility using Average True Range.
"""


class ATR:
    """Calculates Average True Range."""

    @staticmethod
    def calculate(highs, lows, closes, period=14):
        """
        Calculate ATR.

        Parameters
        ----------
        highs : list
            High prices.
        lows : list
            Low prices.
        closes : list
            Closing prices.
        period : int
            ATR period.

        Returns
        -------
        float | None
            Latest ATR value.
        """

        if (
            len(highs) <= period
            or len(lows) <= period
            or len(closes) <= period
        ):
            return None

        true_ranges = []

        for i in range(1, len(highs)):
            tr = max(
                highs[i] - lows[i],
                abs(highs[i] - closes[i - 1]),
                abs(lows[i] - closes[i - 1]),
            )

            true_ranges.append(tr)

        atr = sum(true_ranges[:period]) / period

        return round(atr, 2)